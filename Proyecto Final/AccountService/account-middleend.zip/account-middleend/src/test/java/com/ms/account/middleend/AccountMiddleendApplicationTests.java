package com.ms.account.middleend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountMiddleendApplicationTests {

	@Test
	void contextLoads() {
	}

}
