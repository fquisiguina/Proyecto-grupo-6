package com.ms.account.middleend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountMiddleendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountMiddleendApplication.class, args);
	}

}
